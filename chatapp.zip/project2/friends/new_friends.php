<?php require '../classes/init.php'; ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/lib/w3-theme-blue-grey.css">
    <link rel="stylesheet" href="../css/w3.css">
    <title>My Friends</title>
  </head>
  <body class="w3-theme-l2">
    <div class="w3-row">
      <div class="friends w3-col-s-1">
        <img src="../images/avatar1.png" alt="img">
      </div>
    </div>
  </body>
</html>
